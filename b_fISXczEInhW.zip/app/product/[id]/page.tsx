import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { getProductById, getRelatedProducts, products } from '@/lib/data/products'
import { ProductGallery } from '@/components/products/product-gallery'
import { ProductInfo } from '@/components/products/product-info'
import { ProductTabs } from '@/components/products/product-tabs'
import { RelatedProducts } from '@/components/products/related-products'

interface ProductPageProps {
  params: Promise<{ id: string }>
}

export async function generateStaticParams() {
  return products.map((product) => ({
    id: product.id,
  }))
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { id } = await params
  const product = getProductById(id)

  if (!product) {
    return {
      title: 'Product Not Found',
    }
  }

  return {
    title: `${product.name} by ${product.brand}`,
    description: product.description,
    openGraph: {
      title: `${product.name} | Elixir Fragrances`,
      description: product.description,
      images: [product.image],
    },
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { id } = await params
  const product = getProductById(id)

  if (!product) {
    notFound()
  }

  const relatedProducts = getRelatedProducts(product)

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-secondary/30 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="text-sm text-muted-foreground">
            <ol className="flex items-center gap-2">
              <li>
                <a href="/" className="hover:text-primary transition-colors">
                  Home
                </a>
              </li>
              <li>/</li>
              <li>
                <a href="/shop" className="hover:text-primary transition-colors">
                  Shop
                </a>
              </li>
              <li>/</li>
              <li>
                <a
                  href={`/shop?category=${product.category}`}
                  className="hover:text-primary transition-colors capitalize"
                >
                  {product.category}
                </a>
              </li>
              <li>/</li>
              <li className="text-foreground">{product.name}</li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Product Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          <ProductGallery product={product} />
          <ProductInfo product={product} />
        </div>
      </section>

      {/* Product Tabs */}
      <ProductTabs product={product} />

      {/* Related Products */}
      <RelatedProducts products={relatedProducts} />
    </div>
  )
}
