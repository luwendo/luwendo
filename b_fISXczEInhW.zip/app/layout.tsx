import type { Metadata, Viewport } from 'next'
import { Playfair_Display, Montserrat } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'sonner'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { CartProvider } from '@/lib/cart-context'
import './globals.css'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

const montserrat = Montserrat({
  subsets: ['latin'],
  variable: '--font-montserrat',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'Elixir Fragrances | Luxury Perfumes & Exclusive Scents',
    template: '%s | Elixir Fragrances',
  },
  description:
    'Discover exquisite luxury fragrances at Elixir. Shop our curated collection of premium perfumes for men and women. Free shipping on orders over $100.',
  keywords: [
    'luxury perfume',
    'designer fragrance',
    'niche perfume',
    'premium scents',
    'perfume shop',
    'cologne',
    'eau de parfum',
  ],
  authors: [{ name: 'Elixir Fragrances' }],
  creator: 'Elixir Fragrances',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://elixir-fragrances.com',
    siteName: 'Elixir Fragrances',
    title: 'Elixir Fragrances | Luxury Perfumes & Exclusive Scents',
    description:
      'Discover exquisite luxury fragrances at Elixir. Shop our curated collection of premium perfumes.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Elixir Fragrances - Luxury Perfume Collection',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Elixir Fragrances | Luxury Perfumes',
    description: 'Discover exquisite luxury fragrances at Elixir.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#1a1a1a',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${playfair.variable} ${montserrat.variable} bg-background`}>
      <body className="font-sans antialiased min-h-screen flex flex-col">
        <CartProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: 'oklch(0.15 0.01 270)',
                color: 'oklch(0.95 0.01 90)',
                border: '1px solid oklch(0.78 0.12 85 / 0.3)',
              },
            }}
          />
        </CartProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
