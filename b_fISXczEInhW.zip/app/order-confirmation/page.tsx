import Link from 'next/link'
import { Check, Package, Mail, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function OrderConfirmationPage() {
  const orderNumber = `ELX-${Math.random().toString(36).substring(2, 8).toUpperCase()}`

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-lg w-full text-center">
        {/* Success Icon */}
        <div className="mx-auto h-20 w-20 rounded-full bg-primary/20 flex items-center justify-center mb-8">
          <div className="h-14 w-14 rounded-full bg-primary flex items-center justify-center">
            <Check className="h-8 w-8 text-primary-foreground" />
          </div>
        </div>

        {/* Heading */}
        <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-4">
          Thank You for Your Order!
        </h1>
        <p className="text-muted-foreground mb-8">
          Your order has been confirmed and will be shipping soon.
        </p>

        {/* Order Number */}
        <div className="bg-card border border-border rounded-lg p-6 mb-8">
          <p className="text-sm text-muted-foreground mb-2">Order Number</p>
          <p className="font-mono text-xl text-foreground">{orderNumber}</p>
        </div>

        {/* Next Steps */}
        <div className="space-y-4 mb-8">
          <div className="flex items-start gap-4 text-left p-4 bg-secondary/30 rounded-lg">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Mail className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">
                Confirmation Email Sent
              </h3>
              <p className="text-sm text-muted-foreground">
                We&apos;ve sent a confirmation email with your order details and
                tracking information.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4 text-left p-4 bg-secondary/30 rounded-lg">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Package className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">
                Shipping in 1-2 Business Days
              </h3>
              <p className="text-sm text-muted-foreground">
                Your fragrance will be carefully packaged and shipped with
                tracking.
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            asChild
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Link href="/shop" className="flex items-center gap-2">
              Continue Shopping
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/">Return Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
