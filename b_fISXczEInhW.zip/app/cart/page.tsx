'use client'

import Link from 'next/link'
import Image from 'next/image'
import type { Metadata } from 'next'
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, Tag } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import { useCart } from '@/lib/cart-context'
import { formatPrice } from '@/lib/utils'
import { ProductCard } from '@/components/products/product-card'
import { products } from '@/lib/data/products'
import { useState } from 'react'
import { toast } from 'sonner'

export default function CartPage() {
  const { items, updateQuantity, removeFromCart, getCartTotal, clearCart } =
    useCart()
  const [promoCode, setPromoCode] = useState('')
  const [discount, setDiscount] = useState(0)

  const subtotal = getCartTotal()
  const shipping = subtotal >= 100 ? 0 : 12
  const total = subtotal - discount + shipping

  const frequentlyBoughtTogether = products.slice(0, 4)

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === 'ELIXIR10') {
      const discountAmount = subtotal * 0.1
      setDiscount(discountAmount)
      toast.success('Promo code applied! 10% off your order.')
    } else {
      toast.error('Invalid promo code')
    }
  }

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
        <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center mb-6">
          <ShoppingBag className="h-12 w-12 text-muted-foreground" />
        </div>
        <h1 className="font-serif text-2xl text-foreground mb-2">
          Your cart is empty
        </h1>
        <p className="text-muted-foreground text-center mb-8 max-w-md">
          Looks like you haven&apos;t added any fragrances to your cart yet.
          Explore our collection to find your perfect scent.
        </p>
        <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Link href="/shop">
            <ShoppingBag className="h-4 w-4 mr-2" />
            Start Shopping
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-secondary/30 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="font-serif text-3xl lg:text-4xl text-foreground">
            Shopping Cart
          </h1>
          <p className="text-muted-foreground mt-2">
            {items.length} {items.length === 1 ? 'item' : 'items'} in your cart
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {/* Back to Shop */}
            <Button variant="link" asChild className="p-0 h-auto text-muted-foreground">
              <Link href="/shop" className="flex items-center gap-2">
                <ArrowLeft className="h-4 w-4" />
                Continue Shopping
              </Link>
            </Button>

            {/* Items List */}
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={`${item.product.id}-${item.size}`}
                  className="flex gap-4 p-4 bg-card border border-border rounded-lg"
                >
                  {/* Product Image */}
                  <Link
                    href={`/product/${item.product.id}`}
                    className="relative h-32 w-24 bg-muted rounded-md overflow-hidden flex-shrink-0"
                  >
                    <Image
                      src={item.product.image}
                      alt={item.product.name}
                      fill
                      className="object-cover"
                    />
                  </Link>

                  {/* Product Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wider">
                          {item.product.brand}
                        </p>
                        <Link
                          href={`/product/${item.product.id}`}
                          className="font-serif text-lg text-foreground hover:text-primary transition-colors"
                        >
                          {item.product.name}
                        </Link>
                        <p className="text-sm text-primary mt-1">
                          {item.size}ml
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => removeFromCart(item.product.id, item.size)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex items-center justify-between mt-4">
                      {/* Quantity */}
                      <div className="flex items-center border border-border rounded-md">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9"
                          onClick={() =>
                            updateQuantity(
                              item.product.id,
                              item.size,
                              item.quantity - 1
                            )
                          }
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-10 text-center">{item.quantity}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9"
                          onClick={() =>
                            updateQuantity(
                              item.product.id,
                              item.size,
                              item.quantity + 1
                            )
                          }
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      {/* Price */}
                      <p className="font-semibold text-foreground">
                        {formatPrice(item.price * item.quantity)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Clear Cart */}
            <Button variant="outline" onClick={clearCart} className="text-destructive">
              <Trash2 className="h-4 w-4 mr-2" />
              Clear Cart
            </Button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card border border-border rounded-lg p-6 sticky top-24">
              <h2 className="font-serif text-xl text-foreground mb-6">
                Order Summary
              </h2>

              {/* Promo Code */}
              <div className="mb-6">
                <label className="text-sm text-muted-foreground">
                  Promo Code
                </label>
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Enter code"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="bg-secondary"
                  />
                  <Button variant="outline" onClick={handleApplyPromo}>
                    Apply
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Try ELIXIR10 for 10% off
                </p>
              </div>

              <Separator className="my-4" />

              {/* Totals */}
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="text-foreground">{formatPrice(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-primary flex items-center gap-1">
                      <Tag className="h-3 w-3" />
                      Discount
                    </span>
                    <span className="text-primary">
                      -{formatPrice(discount)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-foreground">
                    {shipping === 0 ? 'Free' : formatPrice(shipping)}
                  </span>
                </div>
                {subtotal < 100 && (
                  <p className="text-xs text-primary">
                    Add {formatPrice(100 - subtotal)} more for free shipping
                  </p>
                )}
                <Separator />
                <div className="flex justify-between font-semibold text-lg">
                  <span className="text-foreground">Total</span>
                  <span className="text-foreground">{formatPrice(total)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <Button
                asChild
                size="lg"
                className="w-full mt-6 bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Link href="/checkout">Proceed to Checkout</Link>
              </Button>

              {/* Trust Badges */}
              <div className="mt-6 pt-6 border-t border-border">
                <div className="flex justify-center gap-4 opacity-60">
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/0/04/Visa.svg"
                    alt="Visa"
                    className="h-6"
                  />
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Mastercard_2019_logo.svg"
                    alt="Mastercard"
                    className="h-6"
                  />
                  <img
                    src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg"
                    alt="PayPal"
                    className="h-6"
                  />
                </div>
                <p className="text-xs text-center text-muted-foreground mt-3">
                  Secure checkout powered by Stripe
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Frequently Bought Together */}
        <section className="mt-16">
          <h2 className="font-serif text-2xl text-foreground mb-6">
            Frequently Bought Together
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {frequentlyBoughtTogether.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
