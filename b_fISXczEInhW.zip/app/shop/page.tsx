import { Suspense } from 'react'
import type { Metadata } from 'next'
import { ShopContent } from '@/components/shop/shop-content'
import { Spinner } from '@/components/ui/spinner'

export const metadata: Metadata = {
  title: 'Shop Luxury Fragrances',
  description:
    'Explore our curated collection of luxury perfumes for men, women, and niche fragrances. Free shipping on orders over $100.',
}

export default function ShopPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <div className="bg-secondary/30 py-12 lg:py-16 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="font-serif text-4xl lg:text-5xl text-foreground mb-4">
            Our Collection
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover extraordinary fragrances crafted with the finest ingredients.
            Each scent tells a unique story, waiting to become yours.
          </p>
        </div>
      </div>

      {/* Shop Content */}
      <Suspense
        fallback={
          <div className="flex items-center justify-center py-20">
            <Spinner className="h-8 w-8 text-primary" />
          </div>
        }
      >
        <ShopContent />
      </Suspense>
    </div>
  )
}
