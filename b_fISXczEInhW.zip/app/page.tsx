import { HeroSection } from '@/components/home/hero-section'
import { FeaturedCollections } from '@/components/home/featured-collections'
import { BrandStory } from '@/components/home/brand-story'
import { Testimonials } from '@/components/home/testimonials'
import { NewsletterSection } from '@/components/home/newsletter-section'

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <FeaturedCollections />
      <BrandStory />
      <Testimonials />
      <NewsletterSection />
    </>
  )
}
