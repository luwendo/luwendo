"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { Calendar, Clock, ArrowRight, User } from "lucide-react";
import { Button } from "@/components/ui/button";

const blogPosts = [
  {
    id: 1,
    title: "The Art of Fragrance Layering: Creating Your Signature Scent",
    excerpt:
      "Discover the secrets of combining multiple fragrances to create a unique, personalized scent that's entirely your own.",
    image: "/blog/fragrance-layering.jpg",
    author: "Sophie Laurent",
    date: "March 15, 2024",
    readTime: "5 min read",
    category: "Fragrance Tips",
    featured: true,
  },
  {
    id: 2,
    title: "Summer Scents 2024: Fresh Fragrances for Warm Days",
    excerpt:
      "Explore our curated selection of light, refreshing perfumes perfect for the summer season.",
    image: "/blog/summer-scents.jpg",
    author: "Antoine Dubois",
    date: "March 10, 2024",
    readTime: "4 min read",
    category: "Seasonal Picks",
    featured: false,
  },
  {
    id: 3,
    title: "How to Store Your Perfume Collection Properly",
    excerpt:
      "Learn the best practices for preserving your fragrances and maintaining their quality for years to come.",
    image: "/blog/perfume-storage.jpg",
    author: "Marie Chen",
    date: "March 5, 2024",
    readTime: "6 min read",
    category: "Care Guide",
    featured: false,
  },
];

const categories = [
  "All Posts",
  "Fragrance Tips",
  "Seasonal Picks",
  "Care Guide",
  "Behind the Scenes",
  "New Releases",
];

export default function BlogPage() {
  const featuredPost = blogPosts.find((post) => post.featured);
  const regularPosts = blogPosts.filter((post) => !post.featured);

  return (
    <main className="min-h-screen bg-background py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">
            The Elixir Journal
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Discover fragrance insights, tips, and the stories behind our
            creations.
          </p>
        </motion.div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category, index) => (
            <Button
              key={category}
              variant={index === 0 ? "default" : "outline"}
              size="sm"
              className={
                index === 0
                  ? "bg-primary text-primary-foreground"
                  : "border-border hover:border-primary hover:text-primary"
              }
            >
              {category}
            </Button>
          ))}
        </motion.div>

        {/* Featured Post */}
        {featuredPost && (
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-16"
          >
            <Link href={`/blog/${featuredPost.id}`} className="group block">
              <div className="grid lg:grid-cols-2 gap-8 bg-card rounded-lg border border-border overflow-hidden group-hover:border-primary/30 transition-colors">
                <div className="relative aspect-[16/10] lg:aspect-auto">
                  <Image
                    src={featuredPost.image}
                    alt={featuredPost.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-primary text-primary-foreground text-sm font-medium rounded-full">
                      Featured
                    </span>
                  </div>
                </div>
                <div className="p-8 flex flex-col justify-center">
                  <span className="text-primary text-sm font-medium mb-2">
                    {featuredPost.category}
                  </span>
                  <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-4 group-hover:text-primary transition-colors">
                    {featuredPost.title}
                  </h2>
                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {featuredPost.excerpt}
                  </p>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
                    <span className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {featuredPost.author}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {featuredPost.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {featuredPost.readTime}
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-2 text-primary font-medium group-hover:gap-3 transition-all">
                    Read Article
                    <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </Link>
          </motion.article>
        )}

        {/* Regular Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {regularPosts.map((post, index) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
            >
              <Link href={`/blog/${post.id}`} className="group block h-full">
                <div className="bg-card rounded-lg border border-border overflow-hidden h-full flex flex-col group-hover:border-primary/30 transition-colors">
                  <div className="relative aspect-[16/10]">
                    <Image
                      src={post.image}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <span className="text-primary text-sm font-medium mb-2">
                      {post.category}
                    </span>
                    <h3 className="font-serif text-xl text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed line-clamp-3 flex-1">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground pt-4 border-t border-border">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {post.date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {post.readTime}
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.article>
          ))}
        </div>

        {/* Newsletter CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <div className="bg-card rounded-lg border border-border p-8 md:p-12">
            <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-4">
              Never Miss a Story
            </h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Subscribe to our newsletter for the latest fragrance insights and
              exclusive content.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:border-primary"
              />
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 px-8">
                Subscribe
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </main>
  );
}
