"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Leaf, Heart, Award, Globe } from "lucide-react";

const values = [
  {
    icon: Leaf,
    title: "Sustainability",
    description:
      "We source our ingredients responsibly and use eco-friendly packaging to minimize our environmental footprint.",
  },
  {
    icon: Heart,
    title: "Craftsmanship",
    description:
      "Each fragrance is meticulously crafted by master perfumers using traditional techniques passed down through generations.",
  },
  {
    icon: Award,
    title: "Quality",
    description:
      "We use only the finest raw materials, sourced from the world's most renowned ingredient houses.",
  },
  {
    icon: Globe,
    title: "Diversity",
    description:
      "Our collection celebrates scents from every corner of the world, embracing diverse olfactory traditions.",
  },
];

const timeline = [
  {
    year: "1987",
    title: "The Beginning",
    description:
      "Elixir Fragrances was founded in Paris by master perfumer Antoine Dubois with a vision to create exceptional fragrances.",
  },
  {
    year: "1995",
    title: "International Expansion",
    description:
      "Opened flagship stores in London, New York, and Tokyo, bringing luxury fragrances to a global audience.",
  },
  {
    year: "2005",
    title: "Sustainability Commitment",
    description:
      "Launched our Green Initiative, committing to 100% sustainable sourcing and eco-friendly packaging.",
  },
  {
    year: "2015",
    title: "Artisan Collection",
    description:
      "Introduced our exclusive Artisan Collection, featuring rare ingredients from around the world.",
  },
  {
    year: "2023",
    title: "Digital Innovation",
    description:
      "Launched our AI-powered scent matching technology and personalized fragrance consultations.",
  },
];

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[500px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/about-hero.jpg"
            alt="Elixir Fragrances atelier"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="font-serif text-4xl md:text-6xl lg:text-7xl text-foreground mb-6"
          >
            Our Story
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed"
          >
            For over three decades, Elixir Fragrances has been crafting
            exceptional scents that capture the essence of luxury and elegance.
          </motion.p>
        </div>
      </section>

      {/* Brand Story */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6">
                The Art of <span className="text-primary">Perfumery</span>
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Founded in the heart of Paris in 1987, Elixir Fragrances began
                  as a small atelier with a grand vision: to create fragrances
                  that transcend the ordinary and become an extension of
                  one&apos;s identity.
                </p>
                <p>
                  Our founder, Antoine Dubois, believed that every scent tells a
                  story. Drawing inspiration from his travels across continents
                  and his deep understanding of botanical essences, he developed
                  a unique approach to perfumery that combines traditional
                  craftsmanship with innovative techniques.
                </p>
                <p>
                  Today, Elixir Fragrances continues this legacy, working with
                  master perfumers from around the world to create compositions
                  that are both timeless and contemporary. Each fragrance in our
                  collection is a testament to our commitment to excellence.
                </p>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="relative aspect-[4/5] rounded-lg overflow-hidden"
            >
              <Image
                src="/brand-story.jpg"
                alt="Perfumer at work"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 border border-primary/20 rounded-lg" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-4 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">
              Our Values
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              The principles that guide everything we do, from sourcing
              ingredients to crafting the final bottle.
            </p>
          </motion.div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center group"
              >
                <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <value.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-serif text-xl text-foreground mb-3">
                  {value.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">
              Our Journey
            </h2>
            <p className="text-muted-foreground">
              Key milestones in the Elixir Fragrances story.
            </p>
          </motion.div>
          <div className="relative">
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-primary/30 -translate-x-1/2" />
            {timeline.map((item, index) => (
              <motion.div
                key={item.year}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`relative flex items-center mb-12 ${
                  index % 2 === 0
                    ? "md:flex-row"
                    : "md:flex-row-reverse md:text-right"
                }`}
              >
                <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-primary rounded-full -translate-x-1/2 border-4 border-background" />
                <div
                  className={`ml-12 md:ml-0 md:w-1/2 ${
                    index % 2 === 0 ? "md:pr-12" : "md:pl-12"
                  }`}
                >
                  <span className="text-primary font-serif text-2xl">
                    {item.year}
                  </span>
                  <h3 className="font-serif text-xl text-foreground mt-2 mb-2">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Sustainability */}
      <section className="py-20 px-4 bg-card/30">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="relative aspect-[4/3] rounded-lg overflow-hidden order-2 lg:order-1"
            >
              <Image
                src="/sustainability.jpg"
                alt="Sustainable ingredients"
                fill
                className="object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2"
            >
              <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6">
                Committed to <span className="text-primary">Sustainability</span>
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  At Elixir Fragrances, we believe luxury and sustainability go
                  hand in hand. Our commitment to the environment is reflected
                  in every aspect of our business.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                    <span>
                      100% recyclable and biodegradable packaging materials
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                    <span>
                      Ethically sourced ingredients from certified suppliers
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                    <span>Carbon-neutral shipping and operations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2" />
                    <span>
                      Supporting local communities in sourcing regions
                    </span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </main>
  );
}
