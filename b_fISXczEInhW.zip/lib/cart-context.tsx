'use client'

import { createContext, useContext, useCallback, type ReactNode } from 'react'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Product } from './data/products'

export interface CartItem {
  product: Product
  quantity: number
  size: number
  price: number
}

interface CartState {
  items: CartItem[]
  wishlist: string[]
  addToCart: (product: Product, size: number, quantity?: number) => void
  removeFromCart: (productId: string, size: number) => void
  updateQuantity: (productId: string, size: number, quantity: number) => void
  clearCart: () => void
  toggleWishlist: (productId: string) => void
  isInWishlist: (productId: string) => boolean
  getCartTotal: () => number
  getCartCount: () => number
}

const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      wishlist: [],

      addToCart: (product, size, quantity = 1) => {
        set((state) => {
          const existingIndex = state.items.findIndex(
            (item) => item.product.id === product.id && item.size === size
          )

          const sizeOption = product.sizes.find((s) => s.ml === size)
          const price = sizeOption?.price || product.price

          if (existingIndex > -1) {
            const newItems = [...state.items]
            newItems[existingIndex].quantity += quantity
            return { items: newItems }
          }

          return {
            items: [...state.items, { product, quantity, size, price }],
          }
        })
      },

      removeFromCart: (productId, size) => {
        set((state) => ({
          items: state.items.filter(
            (item) => !(item.product.id === productId && item.size === size)
          ),
        }))
      },

      updateQuantity: (productId, size, quantity) => {
        set((state) => {
          if (quantity <= 0) {
            return {
              items: state.items.filter(
                (item) => !(item.product.id === productId && item.size === size)
              ),
            }
          }

          return {
            items: state.items.map((item) =>
              item.product.id === productId && item.size === size
                ? { ...item, quantity }
                : item
            ),
          }
        })
      },

      clearCart: () => set({ items: [] }),

      toggleWishlist: (productId) => {
        set((state) => ({
          wishlist: state.wishlist.includes(productId)
            ? state.wishlist.filter((id) => id !== productId)
            : [...state.wishlist, productId],
        }))
      },

      isInWishlist: (productId) => {
        return get().wishlist.includes(productId)
      },

      getCartTotal: () => {
        return get().items.reduce(
          (total, item) => total + item.price * item.quantity,
          0
        )
      },

      getCartCount: () => {
        return get().items.reduce((count, item) => count + item.quantity, 0)
      },
    }),
    {
      name: 'elixir-cart',
    }
  )
)

const CartContext = createContext<typeof useCartStore | null>(null)

export function CartProvider({ children }: { children: ReactNode }) {
  return (
    <CartContext.Provider value={useCartStore}>{children}</CartContext.Provider>
  )
}

export function useCart() {
  const store = useContext(CartContext)
  if (!store) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return store()
}
