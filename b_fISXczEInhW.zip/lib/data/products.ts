export interface Product {
  id: string
  name: string
  brand: string
  price: number
  originalPrice?: number
  rating: number
  reviewCount: number
  image: string
  images: string[]
  category: 'men' | 'women' | 'unisex' | 'niche'
  notes: {
    top: string[]
    heart: string[]
    base: string[]
  }
  description: string
  longevity: 'Light' | 'Moderate' | 'Long-lasting' | 'Very long-lasting'
  sillage: 'Intimate' | 'Moderate' | 'Strong' | 'Enormous'
  sizes: { ml: number; price: number }[]
  isNew?: boolean
  isBestSeller?: boolean
  isOnSale?: boolean
  tags: string[]
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Midnight Orchid',
    brand: 'Elixir Collection',
    price: 150,
    rating: 4.8,
    reviewCount: 124,
    image: '/products/midnight-orchid.jpg',
    images: ['/products/midnight-orchid.jpg', '/products/midnight-orchid-2.jpg'],
    category: 'women',
    notes: {
      top: ['Black Pepper', 'Pink Pepper', 'Bergamot'],
      heart: ['Black Orchid', 'Jasmine', 'Tuberose'],
      base: ['Sandalwood', 'Amber', 'Musk'],
    },
    description:
      'An intoxicating blend of rare black orchid and warm amber, Midnight Orchid is a sophisticated evening fragrance that captivates with its mysterious allure. The perfect choice for those who dare to stand out.',
    longevity: 'Long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 30, price: 85 },
      { ml: 50, price: 150 },
      { ml: 100, price: 220 },
    ],
    isBestSeller: true,
    tags: ['floral', 'woody', 'evening'],
  },
  {
    id: '2',
    name: 'Velvet Oud',
    brand: 'Elixir Collection',
    price: 295,
    rating: 4.9,
    reviewCount: 89,
    image: '/products/velvet-oud.jpg',
    images: ['/products/velvet-oud.jpg', '/products/velvet-oud-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['Saffron', 'Rose', 'Cardamom'],
      heart: ['Oud', 'Leather', 'Incense'],
      base: ['Amber', 'Sandalwood', 'Vanilla'],
    },
    description:
      'A luxurious journey through ancient spice routes, Velvet Oud combines the finest Arabian oud with Bulgarian rose. This opulent fragrance is for the connoisseur who appreciates rare and precious ingredients.',
    longevity: 'Very long-lasting',
    sillage: 'Enormous',
    sizes: [
      { ml: 30, price: 165 },
      { ml: 50, price: 295 },
      { ml: 100, price: 450 },
    ],
    isBestSeller: true,
    tags: ['oud', 'spicy', 'luxurious'],
  },
  {
    id: '3',
    name: 'Ocean Breeze',
    brand: 'Elixir Collection',
    price: 120,
    rating: 4.6,
    reviewCount: 156,
    image: '/products/ocean-breeze.jpg',
    images: ['/products/ocean-breeze.jpg', '/products/ocean-breeze-2.jpg'],
    category: 'men',
    notes: {
      top: ['Sea Salt', 'Bergamot', 'Grapefruit'],
      heart: ['Lavender', 'Geranium', 'Marine Accord'],
      base: ['Driftwood', 'White Musk', 'Ambergris'],
    },
    description:
      'Capture the essence of a Mediterranean morning with Ocean Breeze. Fresh, invigorating, and effortlessly elegant, this fragrance evokes endless summer days by crystalline waters.',
    longevity: 'Moderate',
    sillage: 'Moderate',
    sizes: [
      { ml: 50, price: 120 },
      { ml: 100, price: 180 },
    ],
    isNew: true,
    tags: ['fresh', 'aquatic', 'daytime'],
  },
  {
    id: '4',
    name: 'Rose Elixir',
    brand: 'Elixir Collection',
    price: 175,
    rating: 4.7,
    reviewCount: 203,
    image: '/products/rose-elixir.jpg',
    images: ['/products/rose-elixir.jpg', '/products/rose-elixir-2.jpg'],
    category: 'women',
    notes: {
      top: ['Lychee', 'Raspberry', 'Pear'],
      heart: ['Rose de Mai', 'Peony', 'Magnolia'],
      base: ['White Musk', 'Cedar', 'Ambroxan'],
    },
    description:
      'A modern interpretation of the classic rose, Rose Elixir combines dewy petals with juicy fruits and soft musks. Feminine, romantic, and utterly timeless.',
    longevity: 'Long-lasting',
    sillage: 'Moderate',
    sizes: [
      { ml: 30, price: 95 },
      { ml: 50, price: 175 },
      { ml: 100, price: 265 },
    ],
    isBestSeller: true,
    tags: ['floral', 'romantic', 'feminine'],
  },
  {
    id: '5',
    name: 'Noir Absolu',
    brand: 'Maison Elixir',
    price: 385,
    rating: 4.9,
    reviewCount: 67,
    image: '/products/noir-absolu.jpg',
    images: ['/products/noir-absolu.jpg', '/products/noir-absolu-2.jpg'],
    category: 'niche',
    notes: {
      top: ['Black Truffle', 'Rum', 'Tobacco'],
      heart: ['Dark Chocolate', 'Coffee', 'Iris'],
      base: ['Benzoin', 'Tonka Bean', 'Leather'],
    },
    description:
      'Decadent and unapologetically bold, Noir Absolu is a masterpiece of dark sophistication. Rich gourmand notes intertwine with smoky leather for an unforgettable signature scent.',
    longevity: 'Very long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 50, price: 385 },
      { ml: 100, price: 580 },
    ],
    isNew: true,
    tags: ['gourmand', 'smoky', 'luxurious'],
  },
  {
    id: '6',
    name: 'Citrus Paradiso',
    brand: 'Elixir Collection',
    price: 95,
    originalPrice: 125,
    rating: 4.5,
    reviewCount: 178,
    image: '/products/citrus-paradiso.jpg',
    images: ['/products/citrus-paradiso.jpg', '/products/citrus-paradiso-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['Sicilian Lemon', 'Mandarin', 'Grapefruit'],
      heart: ['Neroli', 'Petitgrain', 'Orange Blossom'],
      base: ['White Tea', 'Musk', 'Cedar'],
    },
    description:
      'A burst of Italian sunshine in a bottle. Citrus Paradiso is an effervescent celebration of Mediterranean citrus groves, perfect for brightening any day.',
    longevity: 'Moderate',
    sillage: 'Moderate',
    sizes: [
      { ml: 50, price: 95 },
      { ml: 100, price: 145 },
    ],
    isOnSale: true,
    tags: ['citrus', 'fresh', 'energizing'],
  },
  {
    id: '7',
    name: 'Sandalwood Dreams',
    brand: 'Maison Elixir',
    price: 245,
    rating: 4.8,
    reviewCount: 92,
    image: '/products/sandalwood-dreams.jpg',
    images: ['/products/sandalwood-dreams.jpg', '/products/sandalwood-dreams-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['Cardamom', 'Pink Pepper', 'Elemi'],
      heart: ['Australian Sandalwood', 'Iris', 'Violet Leaf'],
      base: ['Cashmeran', 'Musks', 'Cedarwood'],
    },
    description:
      'Pure Australian sandalwood takes center stage in this creamy, sophisticated fragrance. Sandalwood Dreams is meditation in a bottle - calming, centering, and infinitely refined.',
    longevity: 'Long-lasting',
    sillage: 'Intimate',
    sizes: [
      { ml: 30, price: 135 },
      { ml: 50, price: 245 },
      { ml: 100, price: 365 },
    ],
    tags: ['woody', 'creamy', 'sophisticated'],
  },
  {
    id: '8',
    name: 'Amber Mystique',
    brand: 'Elixir Collection',
    price: 165,
    rating: 4.7,
    reviewCount: 145,
    image: '/products/amber-mystique.jpg',
    images: ['/products/amber-mystique.jpg', '/products/amber-mystique-2.jpg'],
    category: 'women',
    notes: {
      top: ['Bitter Orange', 'Cinnamon', 'Plum'],
      heart: ['Amber', 'Benzoin', 'Labdanum'],
      base: ['Vanilla', 'Sandalwood', 'Musk'],
    },
    description:
      'Wrap yourself in the warmth of golden amber with this enchanting oriental fragrance. Amber Mystique is like a cashmere blanket on a cold winter night - comforting, sensual, and irresistible.',
    longevity: 'Very long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 30, price: 90 },
      { ml: 50, price: 165 },
      { ml: 100, price: 250 },
    ],
    isBestSeller: true,
    tags: ['amber', 'oriental', 'warm'],
  },
  {
    id: '9',
    name: 'Gentleman\'s Club',
    brand: 'Elixir Collection',
    price: 135,
    rating: 4.6,
    reviewCount: 167,
    image: '/products/gentlemans-club.jpg',
    images: ['/products/gentlemans-club.jpg', '/products/gentlemans-club-2.jpg'],
    category: 'men',
    notes: {
      top: ['Whiskey', 'Apple', 'Lavender'],
      heart: ['Tobacco', 'Geranium', 'Cinnamon'],
      base: ['Leather', 'Oud', 'Vetiver'],
    },
    description:
      'Step into an exclusive world of refined masculinity. Gentleman\'s Club combines aged whiskey notes with fine tobacco and supple leather for the modern man of distinction.',
    longevity: 'Long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 50, price: 135 },
      { ml: 100, price: 195 },
    ],
    tags: ['masculine', 'tobacco', 'sophisticated'],
  },
  {
    id: '10',
    name: 'White Tea Serenity',
    brand: 'Elixir Collection',
    price: 110,
    rating: 4.4,
    reviewCount: 134,
    image: '/products/white-tea-serenity.jpg',
    images: ['/products/white-tea-serenity.jpg', '/products/white-tea-serenity-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['White Tea', 'Bergamot', 'Mandarin'],
      heart: ['Sea Breeze', 'Jasmine', 'Moss'],
      base: ['Blonde Woods', 'Musk', 'Amber'],
    },
    description:
      'Find your calm with White Tea Serenity. This clean, meditative fragrance combines the purity of white tea with soft woods for a scent that soothes the soul.',
    longevity: 'Moderate',
    sillage: 'Intimate',
    sizes: [
      { ml: 50, price: 110 },
      { ml: 100, price: 165 },
    ],
    isNew: true,
    tags: ['clean', 'fresh', 'calming'],
  },
  {
    id: '11',
    name: 'Jasmine Nights',
    brand: 'Maison Elixir',
    price: 285,
    rating: 4.8,
    reviewCount: 78,
    image: '/products/jasmine-nights.jpg',
    images: ['/products/jasmine-nights.jpg', '/products/jasmine-nights-2.jpg'],
    category: 'women',
    notes: {
      top: ['Ylang Ylang', 'Neroli', 'Bergamot'],
      heart: ['Jasmine Sambac', 'Tuberose', 'Gardenia'],
      base: ['Sandalwood', 'Benzoin', 'Vanilla'],
    },
    description:
      'Intoxicating jasmine blooms at midnight, releasing their most potent perfume. Jasmine Nights captures this magical moment in a seductive white floral masterpiece.',
    longevity: 'Very long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 30, price: 155 },
      { ml: 50, price: 285 },
      { ml: 100, price: 425 },
    ],
    tags: ['floral', 'white flowers', 'seductive'],
  },
  {
    id: '12',
    name: 'Cedar & Smoke',
    brand: 'Elixir Collection',
    price: 145,
    rating: 4.7,
    reviewCount: 112,
    image: '/products/cedar-smoke.jpg',
    images: ['/products/cedar-smoke.jpg', '/products/cedar-smoke-2.jpg'],
    category: 'men',
    notes: {
      top: ['Juniper', 'Black Pepper', 'Ginger'],
      heart: ['Smoky Accord', 'Birch', 'Clary Sage'],
      base: ['Atlas Cedar', 'Vetiver', 'Patchouli'],
    },
    description:
      'Inspired by campfires under starlit skies, Cedar & Smoke is an adventurous fragrance for the modern explorer. Rugged cedar meets smoky birch in this untamed masculine scent.',
    longevity: 'Long-lasting',
    sillage: 'Moderate',
    sizes: [
      { ml: 50, price: 145 },
      { ml: 100, price: 215 },
    ],
    tags: ['woody', 'smoky', 'masculine'],
  },
  {
    id: '13',
    name: 'Vanilla Orchid',
    brand: 'Elixir Collection',
    price: 155,
    originalPrice: 195,
    rating: 4.6,
    reviewCount: 189,
    image: '/products/vanilla-orchid.jpg',
    images: ['/products/vanilla-orchid.jpg', '/products/vanilla-orchid-2.jpg'],
    category: 'women',
    notes: {
      top: ['Bergamot', 'Pear', 'Blackcurrant'],
      heart: ['Orchid', 'Heliotrope', 'Jasmine'],
      base: ['Madagascar Vanilla', 'Tonka Bean', 'White Musk'],
    },
    description:
      'A gourmand floral that\'s utterly addictive. Vanilla Orchid weaves together lush orchid petals with creamy vanilla for a fragrance that\'s both innocent and seductive.',
    longevity: 'Long-lasting',
    sillage: 'Moderate',
    sizes: [
      { ml: 30, price: 85 },
      { ml: 50, price: 155 },
      { ml: 100, price: 235 },
    ],
    isOnSale: true,
    tags: ['vanilla', 'gourmand', 'sweet'],
  },
  {
    id: '14',
    name: 'Iris Royale',
    brand: 'Maison Elixir',
    price: 420,
    rating: 4.9,
    reviewCount: 45,
    image: '/products/iris-royale.jpg',
    images: ['/products/iris-royale.jpg', '/products/iris-royale-2.jpg'],
    category: 'niche',
    notes: {
      top: ['Carrot Seed', 'Pink Pepper', 'Bergamot'],
      heart: ['Iris Pallida', 'Orris Butter', 'Violet'],
      base: ['Suede', 'Amber', 'Sandalwood'],
    },
    description:
      'The queen of florals takes center stage in this ultra-luxurious creation. Iris Royale showcases the finest Italian iris root, aged for years to achieve unparalleled depth and elegance.',
    longevity: 'Very long-lasting',
    sillage: 'Moderate',
    sizes: [
      { ml: 50, price: 420 },
      { ml: 100, price: 650 },
    ],
    isNew: true,
    tags: ['iris', 'powdery', 'luxurious'],
  },
  {
    id: '15',
    name: 'Spice Market',
    brand: 'Elixir Collection',
    price: 140,
    rating: 4.5,
    reviewCount: 98,
    image: '/products/spice-market.jpg',
    images: ['/products/spice-market.jpg', '/products/spice-market-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['Saffron', 'Cumin', 'Coriander'],
      heart: ['Cinnamon', 'Clove', 'Rose'],
      base: ['Amber', 'Patchouli', 'Sandalwood'],
    },
    description:
      'Transport yourself to the bustling souks of Marrakech. Spice Market is a vibrant oriental fragrance that celebrates exotic spices and precious resins from around the world.',
    longevity: 'Long-lasting',
    sillage: 'Strong',
    sizes: [
      { ml: 50, price: 140 },
      { ml: 100, price: 210 },
    ],
    tags: ['spicy', 'oriental', 'exotic'],
  },
  {
    id: '16',
    name: 'Fresh Linen',
    brand: 'Elixir Collection',
    price: 85,
    rating: 4.3,
    reviewCount: 167,
    image: '/products/fresh-linen.jpg',
    images: ['/products/fresh-linen.jpg', '/products/fresh-linen-2.jpg'],
    category: 'unisex',
    notes: {
      top: ['Aldehydes', 'Cucumber', 'Green Apple'],
      heart: ['Cotton Flower', 'Lily', 'Cyclamen'],
      base: ['White Musk', 'Cedar', 'Soft Woods'],
    },
    description:
      'Clean, crisp, and effortlessly fresh. Fresh Linen captures the simple pleasure of sun-dried sheets and springtime air. A everyday essential for the minimalist.',
    longevity: 'Moderate',
    sillage: 'Intimate',
    sizes: [
      { ml: 50, price: 85 },
      { ml: 100, price: 125 },
    ],
    tags: ['clean', 'fresh', 'everyday'],
  },
  {
    id: '17',
    name: 'Vetiver Homme',
    brand: 'Elixir Collection',
    price: 125,
    rating: 4.6,
    reviewCount: 134,
    image: '/products/vetiver-homme.jpg',
    images: ['/products/vetiver-homme.jpg', '/products/vetiver-homme-2.jpg'],
    category: 'men',
    notes: {
      top: ['Grapefruit', 'Lemon', 'Mandarin'],
      heart: ['Vetiver', 'Orris', 'Geranium'],
      base: ['Vetiver Root', 'Oakmoss', 'Musk'],
    },
    description:
      'A masterclass in masculine elegance. Vetiver Homme celebrates the earthy, smoky beauty of Haitian vetiver in a refined, office-appropriate composition.',
    longevity: 'Long-lasting',
    sillage: 'Moderate',
    sizes: [
      { ml: 50, price: 125 },
      { ml: 100, price: 185 },
    ],
    tags: ['vetiver', 'green', 'classic'],
  },
  {
    id: '18',
    name: 'Cherry Blossom',
    brand: 'Elixir Collection',
    price: 115,
    rating: 4.5,
    reviewCount: 156,
    image: '/products/cherry-blossom.jpg',
    images: ['/products/cherry-blossom.jpg', '/products/cherry-blossom-2.jpg'],
    category: 'women',
    notes: {
      top: ['Cherry', 'Bergamot', 'Pink Pepper'],
      heart: ['Cherry Blossom', 'Rose', 'Magnolia'],
      base: ['Sandalwood', 'Musk', 'Praline'],
    },
    description:
      'Spring eternal in a bottle. Cherry Blossom captures the fleeting beauty of Japanese sakura season with delicate petals, sweet cherry, and soft woods.',
    longevity: 'Moderate',
    sillage: 'Moderate',
    sizes: [
      { ml: 30, price: 65 },
      { ml: 50, price: 115 },
      { ml: 100, price: 175 },
    ],
    tags: ['floral', 'fruity', 'romantic'],
  },
  {
    id: '19',
    name: 'Oud Extrait',
    brand: 'Maison Elixir',
    price: 550,
    rating: 5.0,
    reviewCount: 34,
    image: '/products/oud-extrait.jpg',
    images: ['/products/oud-extrait.jpg', '/products/oud-extrait-2.jpg'],
    category: 'niche',
    notes: {
      top: ['Rose Absolute', 'Saffron', 'Honey'],
      heart: ['Cambodian Oud', 'Taif Rose', 'Frankincense'],
      base: ['Aged Oud', 'Ambergris', 'Musk'],
    },
    description:
      'Our most exclusive creation. Oud Extrait features 30-year-aged Cambodian oud in an extraordinarily concentrated formula. Limited to 500 bottles annually.',
    longevity: 'Very long-lasting',
    sillage: 'Enormous',
    sizes: [{ ml: 30, price: 550 }],
    tags: ['oud', 'exclusive', 'ultra-luxurious'],
  },
  {
    id: '20',
    name: 'Summer Garden',
    brand: 'Elixir Collection',
    price: 98,
    originalPrice: 130,
    rating: 4.4,
    reviewCount: 145,
    image: '/products/summer-garden.jpg',
    images: ['/products/summer-garden.jpg', '/products/summer-garden-2.jpg'],
    category: 'women',
    notes: {
      top: ['Green Apple', 'Pear', 'Cassis'],
      heart: ['Rose', 'Lily of the Valley', 'Peony'],
      base: ['Light Musk', 'Cedar', 'Fresh Moss'],
    },
    description:
      'Step into an English garden in full bloom. Summer Garden is a joyful, effervescent floral that captures the carefree spirit of warm sunny days.',
    longevity: 'Light',
    sillage: 'Intimate',
    sizes: [
      { ml: 30, price: 55 },
      { ml: 50, price: 98 },
      { ml: 100, price: 145 },
    ],
    isOnSale: true,
    tags: ['floral', 'green', 'fresh'],
  },
]

export const categories = [
  { id: 'all', name: 'All Fragrances' },
  { id: 'men', name: 'For Him' },
  { id: 'women', name: 'For Her' },
  { id: 'unisex', name: 'Unisex' },
  { id: 'niche', name: 'Niche Collection' },
]

export const noteTypes = [
  'floral',
  'woody',
  'spicy',
  'fresh',
  'citrus',
  'oriental',
  'oud',
  'gourmand',
  'aquatic',
  'powdery',
]

export const priceRanges = [
  { id: '0-100', label: 'Under $100', min: 0, max: 100 },
  { id: '100-200', label: '$100 - $200', min: 100, max: 200 },
  { id: '200-300', label: '$200 - $300', min: 200, max: 300 },
  { id: '300+', label: '$300+', min: 300, max: Infinity },
]

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id)
}

export function getRelatedProducts(product: Product, limit = 4): Product[] {
  return products
    .filter((p) => p.id !== product.id && (p.category === product.category || p.tags.some((t) => product.tags.includes(t))))
    .slice(0, limit)
}

export function getBestSellers(): Product[] {
  return products.filter((p) => p.isBestSeller)
}

export function getNewArrivals(): Product[] {
  return products.filter((p) => p.isNew)
}

export function getOnSaleProducts(): Product[] {
  return products.filter((p) => p.isOnSale)
}
