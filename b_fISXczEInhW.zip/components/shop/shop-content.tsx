'use client'

import { useState, useMemo } from 'react'
import { useSearchParams } from 'next/navigation'
import {
  SlidersHorizontal,
  Grid3X3,
  LayoutGrid,
  ChevronDown,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { ProductCard } from '@/components/products/product-card'
import { products, categories, noteTypes, priceRanges } from '@/lib/data/products'
import { cn } from '@/lib/utils'

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest'

export function ShopContent() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get('category')
  const filterParam = searchParams.get('filter')

  const [selectedCategory, setSelectedCategory] = useState<string>(
    categoryParam || 'all'
  )
  const [selectedNotes, setSelectedNotes] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 700])
  const [sortBy, setSortBy] = useState<SortOption>('featured')
  const [gridSize, setGridSize] = useState<3 | 4>(4)
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const filteredProducts = useMemo(() => {
    let result = [...products]

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter((p) => p.category === selectedCategory)
    }

    // Special filters from URL
    if (filterParam === 'bestseller') {
      result = result.filter((p) => p.isBestSeller)
    } else if (filterParam === 'new') {
      result = result.filter((p) => p.isNew)
    } else if (filterParam === 'sale') {
      result = result.filter((p) => p.isOnSale)
    }

    // Notes filter
    if (selectedNotes.length > 0) {
      result = result.filter((p) =>
        selectedNotes.some((note) => p.tags.includes(note))
      )
    }

    // Price filter
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    )

    // Sorting
    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        result.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        result.sort((a, b) => b.rating - a.rating)
        break
      case 'newest':
        result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0))
        break
      default:
        result.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0))
    }

    return result
  }, [selectedCategory, selectedNotes, priceRange, sortBy, filterParam])

  const toggleNote = (note: string) => {
    setSelectedNotes((prev) =>
      prev.includes(note) ? prev.filter((n) => n !== note) : [...prev, note]
    )
  }

  const clearFilters = () => {
    setSelectedCategory('all')
    setSelectedNotes([])
    setPriceRange([0, 700])
  }

  const activeFiltersCount =
    (selectedCategory !== 'all' ? 1 : 0) +
    selectedNotes.length +
    (priceRange[0] > 0 || priceRange[1] < 700 ? 1 : 0)

  const FilterContent = () => (
    <div className="space-y-6">
      <Accordion type="multiple" defaultValue={['category', 'notes', 'price']}>
        {/* Category Filter */}
        <AccordionItem value="category">
          <AccordionTrigger className="text-foreground">Category</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    'block w-full text-left py-2 px-3 rounded-md transition-colors text-sm',
                    selectedCategory === cat.id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-secondary'
                  )}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Notes Filter */}
        <AccordionItem value="notes">
          <AccordionTrigger className="text-foreground">Fragrance Notes</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3">
              {noteTypes.map((note) => (
                <div key={note} className="flex items-center gap-2">
                  <Checkbox
                    id={note}
                    checked={selectedNotes.includes(note)}
                    onCheckedChange={() => toggleNote(note)}
                  />
                  <Label
                    htmlFor={note}
                    className="text-sm text-muted-foreground capitalize cursor-pointer"
                  >
                    {note}
                  </Label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Price Filter */}
        <AccordionItem value="price">
          <AccordionTrigger className="text-foreground">Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="px-2">
              <Slider
                value={priceRange}
                onValueChange={(value) => setPriceRange(value as [number, number])}
                min={0}
                max={700}
                step={10}
                className="mb-4"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {activeFiltersCount > 0 && (
        <Button
          variant="outline"
          onClick={clearFilters}
          className="w-full"
        >
          Clear All Filters
        </Button>
      )}
    </div>
  )

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex lg:gap-8">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block w-64 flex-shrink-0">
          <div className="sticky top-24">
            <h2 className="font-medium text-foreground mb-4">Filters</h2>
            <FilterContent />
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1">
          {/* Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-6 border-b border-border">
            {/* Mobile Filter Button */}
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="outline" className="gap-2">
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                  {activeFiltersCount > 0 && (
                    <span className="h-5 w-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 bg-background">
                <SheetHeader>
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterContent />
                </div>
              </SheetContent>
            </Sheet>

            {/* Results Count */}
            <p className="text-sm text-muted-foreground">
              <span className="text-foreground font-medium">
                {filteredProducts.length}
              </span>{' '}
              {filteredProducts.length === 1 ? 'product' : 'products'}
            </p>

            {/* Sort & Grid Controls */}
            <div className="flex items-center gap-4">
              {/* Sort */}
              <Select
                value={sortBy}
                onValueChange={(value) => setSortBy(value as SortOption)}
              >
                <SelectTrigger className="w-40 bg-secondary border-border">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Top Rated</SelectItem>
                </SelectContent>
              </Select>

              {/* Grid Size Toggle */}
              <div className="hidden md:flex items-center border border-border rounded-md">
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    'rounded-none rounded-l-md',
                    gridSize === 3 && 'bg-secondary'
                  )}
                  onClick={() => setGridSize(3)}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    'rounded-none rounded-r-md',
                    gridSize === 4 && 'bg-secondary'
                  )}
                  onClick={() => setGridSize(4)}
                >
                  <LayoutGrid className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {selectedCategory !== 'all' && (
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-secondary rounded-full text-sm">
                  {categories.find((c) => c.id === selectedCategory)?.name}
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className="hover:text-primary"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              )}
              {selectedNotes.map((note) => (
                <span
                  key={note}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-secondary rounded-full text-sm capitalize"
                >
                  {note}
                  <button
                    onClick={() => toggleNote(note)}
                    className="hover:text-primary"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* Products Grid */}
          {filteredProducts.length > 0 ? (
            <div
              className={cn(
                'grid gap-4 lg:gap-6',
                gridSize === 3
                  ? 'grid-cols-2 md:grid-cols-3'
                  : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4'
              )}
            >
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-xl text-foreground mb-2">No products found</p>
              <p className="text-muted-foreground mb-6">
                Try adjusting your filters to find what you&apos;re looking for.
              </p>
              <Button onClick={clearFilters}>Clear All Filters</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
