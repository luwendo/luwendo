'use client'

import { useState } from 'react'
import { Mail, Sparkles } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

export function NewsletterSection() {
  const [email, setEmail] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast.success('Welcome to the Elixir Circle! Check your email for your 10% off code.')
    setEmail('')
    setIsLoading(false)
  }

  return (
    <section className="py-16 lg:py-24 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          {/* Icon */}
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary/10 mb-6">
            <Mail className="h-8 w-8 text-primary" />
          </div>

          {/* Heading */}
          <h2 className="font-serif text-3xl lg:text-4xl text-foreground mb-4">
            Join the Elixir Circle
          </h2>
          <p className="text-muted-foreground mb-8 leading-relaxed">
            Subscribe to receive exclusive offers, early access to new releases,
            fragrance tips from our experts, and{' '}
            <span className="text-primary font-medium">10% off</span> your first
            order.
          </p>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 bg-secondary border-border h-12"
            />
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-primary text-primary-foreground hover:bg-primary/90 h-12 px-8"
            >
              {isLoading ? (
                'Subscribing...'
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Get 10% Off
                </>
              )}
            </Button>
          </form>

          {/* Trust Text */}
          <p className="text-xs text-muted-foreground mt-4">
            By subscribing, you agree to our Privacy Policy. Unsubscribe anytime.
          </p>

          {/* Social Proof */}
          <div className="mt-8 pt-8 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Join <span className="text-foreground font-medium">50,000+</span>{' '}
              fragrance lovers in our community
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
