'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/products/product-card'
import {
  products,
  getBestSellers,
  getNewArrivals,
  getOnSaleProducts,
} from '@/lib/data/products'

interface CollectionSectionProps {
  title: string
  description: string
  products: typeof products
  viewAllHref: string
}

function CollectionSection({
  title,
  description,
  products,
  viewAllHref,
}: CollectionSectionProps) {
  return (
    <section className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
          <div>
            <h2 className="font-serif text-3xl lg:text-4xl text-foreground mb-2">
              {title}
            </h2>
            <p className="text-muted-foreground max-w-lg">{description}</p>
          </div>
          <Button
            variant="link"
            asChild
            className="text-primary hover:text-primary/80 p-0 h-auto self-start sm:self-auto"
          >
            <Link href={viewAllHref} className="flex items-center gap-2">
              View All
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
          {products.slice(0, 4).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  )
}

export function FeaturedCollections() {
  const bestSellers = getBestSellers()
  const newArrivals = getNewArrivals()
  const onSale = getOnSaleProducts()

  return (
    <>
      {/* Best Sellers */}
      <CollectionSection
        title="Best Sellers"
        description="Our most beloved fragrances, chosen by thousands of fragrance enthusiasts."
        products={bestSellers}
        viewAllHref="/shop?filter=bestseller"
      />

      {/* Divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      </div>

      {/* New Arrivals */}
      <CollectionSection
        title="New Arrivals"
        description="Discover our latest creations, fresh from the perfumer's workshop."
        products={newArrivals}
        viewAllHref="/shop?filter=new"
      />

      {/* Divider */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      </div>

      {/* Special Offers */}
      <CollectionSection
        title="Special Offers"
        description="Exceptional fragrances at exceptional prices. Limited time only."
        products={onSale}
        viewAllHref="/shop?filter=sale"
      />
    </>
  )
}
