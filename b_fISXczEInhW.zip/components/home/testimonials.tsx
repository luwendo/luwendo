'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react'
import { cn } from '@/lib/utils'

const testimonials = [
  {
    id: 1,
    name: 'Sophia Anderson',
    location: 'New York, NY',
    image: '/testimonials/person-1.jpg',
    rating: 5,
    product: 'Midnight Orchid',
    text: 'Absolutely divine! Midnight Orchid has become my signature scent. I receive compliments everywhere I go. The longevity is incredible - it lasts from morning to night without fading. Worth every penny.',
  },
  {
    id: 2,
    name: 'Michael Chen',
    location: 'Los Angeles, CA',
    image: '/testimonials/person-2.jpg',
    rating: 5,
    product: 'Velvet Oud',
    text: "As a fragrance collector, I've tried hundreds of ouds. Velvet Oud is exceptional. The quality of ingredients is evident from the first spray. It's sophisticated without being overwhelming. A true masterpiece.",
  },
  {
    id: 3,
    name: 'Emma Williams',
    location: 'London, UK',
    image: '/testimonials/person-3.jpg',
    rating: 5,
    product: 'Rose Elixir',
    text: "Rose Elixir is unlike any rose fragrance I've experienced. It's fresh, modern, and romantic without being too sweet. The packaging is gorgeous too. Elixir has earned a customer for life.",
  },
  {
    id: 4,
    name: 'James Mitchell',
    location: 'Chicago, IL',
    image: '/testimonials/person-2.jpg',
    rating: 5,
    product: "Gentleman's Club",
    text: "Finally, a sophisticated men's fragrance that doesn't smell like every other cologne. Gentleman's Club is unique, refined, and gets noticed. The tobacco and leather notes are perfectly balanced.",
  },
  {
    id: 5,
    name: 'Isabella Romano',
    location: 'Miami, FL',
    image: '/testimonials/person-1.jpg',
    rating: 5,
    product: 'Jasmine Nights',
    text: "Jasmine Nights transports me to a Mediterranean garden at dusk. It's sensual, intoxicating, and utterly beautiful. The sillage is impressive without being overwhelming. A true work of art.",
  },
]

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    }, 5000)

    return () => clearInterval(timer)
  }, [isAutoPlaying])

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
    setIsAutoPlaying(false)
  }

  const prev = () => {
    setCurrentIndex(
      (prev) => (prev - 1 + testimonials.length) % testimonials.length
    )
    setIsAutoPlaying(false)
  }

  return (
    <section className="py-16 lg:py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-primary text-sm font-medium tracking-widest uppercase">
            Testimonials
          </span>
          <h2 className="font-serif text-3xl lg:text-4xl text-foreground mt-4">
            What Our Customers Say
          </h2>
        </div>

        {/* Testimonial Carousel */}
        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="w-full flex-shrink-0 px-4"
                >
                  <div className="max-w-3xl mx-auto text-center">
                    {/* Quote Icon */}
                    <Quote className="h-12 w-12 text-primary/20 mx-auto mb-6" />

                    {/* Stars */}
                    <div className="flex justify-center gap-1 mb-6">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star
                          key={i}
                          className="h-5 w-5 fill-primary text-primary"
                        />
                      ))}
                    </div>

                    {/* Quote Text */}
                    <blockquote className="font-serif text-xl lg:text-2xl text-foreground leading-relaxed mb-8">
                      &quot;{testimonial.text}&quot;
                    </blockquote>

                    {/* Author Info */}
                    <div className="flex items-center justify-center gap-4">
                      <div className="relative h-14 w-14 rounded-full overflow-hidden border-2 border-primary">
                        <Image
                          src={testimonial.image}
                          alt={testimonial.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-foreground">
                          {testimonial.name}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {testimonial.location} • {testimonial.product}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-secondary/80 transition-colors"
            aria-label="Previous testimonial"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 h-10 w-10 rounded-full bg-secondary flex items-center justify-center text-foreground hover:bg-secondary/80 transition-colors"
            aria-label="Next testimonial"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrentIndex(index)
                setIsAutoPlaying(false)
              }}
              className={cn(
                'h-2 rounded-full transition-all duration-300',
                index === currentIndex
                  ? 'w-6 bg-primary'
                  : 'w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50'
              )}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
