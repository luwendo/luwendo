import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Leaf, Award, Heart } from 'lucide-react'
import { Button } from '@/components/ui/button'

const values = [
  {
    icon: Leaf,
    title: 'Sustainable Sourcing',
    description:
      'We partner with ethical suppliers who share our commitment to environmental responsibility.',
  },
  {
    icon: Award,
    title: 'Master Craftsmanship',
    description:
      'Each fragrance is meticulously crafted by world-renowned perfumers with decades of experience.',
  },
  {
    icon: Heart,
    title: 'Passion for Perfection',
    description:
      'We obsess over every detail, from ingredient selection to the final presentation.',
  },
]

export function BrandStory() {
  return (
    <section className="py-16 lg:py-24 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="aspect-[4/5] relative rounded-lg overflow-hidden">
              <Image
                src="/brand-story.jpg"
                alt="The art of perfume creation at Elixir"
                fill
                className="object-cover"
              />
            </div>
            {/* Floating Stats Card */}
            <div className="absolute -bottom-6 -right-6 lg:right-auto lg:-left-6 bg-card border border-border rounded-lg p-6 shadow-2xl">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <p className="font-serif text-3xl text-primary">37+</p>
                  <p className="text-sm text-muted-foreground">Years of Excellence</p>
                </div>
                <div className="text-center">
                  <p className="font-serif text-3xl text-primary">200+</p>
                  <p className="text-sm text-muted-foreground">Unique Fragrances</p>
                </div>
              </div>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="text-primary text-sm font-medium tracking-widest uppercase">
              Our Story
            </span>
            <h2 className="font-serif text-3xl lg:text-4xl xl:text-5xl text-foreground mt-4 mb-6 leading-tight">
              Crafting Extraordinary Fragrances Since 1987
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed mb-8">
              <p>
                At Elixir, we believe that fragrance is more than a scent—it&apos;s
                a story, an emotion, a memory captured in a bottle. Founded by
                master perfumer Jean-Pierre Laurent, our maison has spent over
                three decades pushing the boundaries of olfactory artistry.
              </p>
              <p>
                We source the rarest ingredients from every corner of the globe:
                Bulgarian rose, Indian sandalwood, Haitian vetiver, and
                Cambodian oud. Each element is carefully selected to ensure
                uncompromising quality and authenticity.
              </p>
            </div>

            {/* Values */}
            <div className="space-y-4 mb-8">
              {values.map((value) => (
                <div key={value.title} className="flex gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <value.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium text-foreground">{value.title}</h3>
                    <p className="text-sm text-muted-foreground">
                      {value.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <Button
              asChild
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Link href="/about" className="flex items-center gap-2">
                Discover Our Story
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
