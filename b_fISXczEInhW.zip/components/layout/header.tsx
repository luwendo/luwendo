'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Menu,
  X,
  ChevronDown,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { useCart } from '@/lib/cart-context'
import { cn } from '@/lib/utils'
import { CartDrawer } from '@/components/cart/cart-drawer'

const navLinks = [
  { href: '/shop', label: 'Shop' },
  {
    href: '/shop?category=women',
    label: 'Women',
    submenu: [
      { href: '/shop?category=women', label: 'All Women\'s Fragrances' },
      { href: '/shop?category=women&tag=floral', label: 'Floral' },
      { href: '/shop?category=women&tag=oriental', label: 'Oriental' },
      { href: '/shop?category=women&tag=fresh', label: 'Fresh' },
    ],
  },
  {
    href: '/shop?category=men',
    label: 'Men',
    submenu: [
      { href: '/shop?category=men', label: 'All Men\'s Fragrances' },
      { href: '/shop?category=men&tag=woody', label: 'Woody' },
      { href: '/shop?category=men&tag=fresh', label: 'Fresh' },
      { href: '/shop?category=men&tag=spicy', label: 'Spicy' },
    ],
  },
  { href: '/shop?category=niche', label: 'Niche' },
  { href: '/shop?filter=bestseller', label: 'Best Sellers' },
  { href: '/about', label: 'About' },
  { href: '/blog', label: 'Blog' },
]

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const pathname = usePathname()
  const { getCartCount, wishlist } = useCart()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <>
      {/* Announcement Bar */}
      <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-sm font-medium">
        <span className="hidden sm:inline">
          Complimentary shipping on all orders over $100 | Use code ELIXIR10 for 10% off your first order
        </span>
        <span className="sm:hidden">Free shipping over $100</span>
      </div>

      {/* Main Header */}
      <header
        className={cn(
          'sticky top-0 z-50 transition-all duration-300',
          isScrolled
            ? 'bg-background/95 backdrop-blur-md shadow-lg border-b border-border'
            : 'bg-background'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Mobile Menu Button */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon" aria-label="Open menu">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 bg-background">
                <SheetHeader>
                  <SheetTitle className="font-serif text-2xl text-gradient-gold">
                    Menu
                  </SheetTitle>
                </SheetHeader>
                <nav className="mt-8 flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <div key={link.href}>
                      <Link
                        href={link.href}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={cn(
                          'block py-3 px-4 text-lg transition-colors rounded-lg',
                          pathname === link.href
                            ? 'text-primary bg-primary/10'
                            : 'text-foreground hover:text-primary hover:bg-primary/5'
                        )}
                      >
                        {link.label}
                      </Link>
                      {link.submenu && (
                        <div className="ml-4 border-l border-border pl-4">
                          {link.submenu.map((sub) => (
                            <Link
                              key={sub.href}
                              href={sub.href}
                              onClick={() => setIsMobileMenuOpen(false)}
                              className="block py-2 text-muted-foreground hover:text-primary transition-colors"
                            >
                              {sub.label}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>

            {/* Logo */}
            <Link href="/" className="flex-shrink-0">
              <h1 className="font-serif text-2xl lg:text-3xl tracking-wide text-gradient-gold">
                ELIXIR
              </h1>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) =>
                link.submenu ? (
                  <DropdownMenu key={link.href}>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className={cn(
                          'text-sm font-medium gap-1',
                          pathname.includes(link.href.split('?')[0])
                            ? 'text-primary'
                            : 'text-foreground hover:text-primary'
                        )}
                      >
                        {link.label}
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="center"
                      className="bg-popover border-border w-56"
                    >
                      {link.submenu.map((sub) => (
                        <DropdownMenuItem key={sub.href} asChild>
                          <Link
                            href={sub.href}
                            className="w-full cursor-pointer"
                          >
                            {sub.label}
                          </Link>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Button
                    key={link.href}
                    variant="ghost"
                    asChild
                    className={cn(
                      'text-sm font-medium',
                      pathname === link.href
                        ? 'text-primary'
                        : 'text-foreground hover:text-primary'
                    )}
                  >
                    <Link href={link.href}>{link.label}</Link>
                  </Button>
                )
              )}
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-1">
              {/* Search */}
              <div className="relative">
                {isSearchOpen ? (
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center gap-2 animate-fade-in">
                    <Input
                      type="search"
                      placeholder="Search fragrances..."
                      className="w-48 sm:w-64 bg-secondary border-border"
                      autoFocus
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setIsSearchOpen(false)}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setIsSearchOpen(true)}
                    aria-label="Search"
                  >
                    <Search className="h-5 w-5" />
                  </Button>
                )}
              </div>

              {/* Wishlist */}
              <Button variant="ghost" size="icon" asChild className="relative">
                <Link href="/wishlist" aria-label="Wishlist">
                  <Heart className="h-5 w-5" />
                  {wishlist.length > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 w-5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center justify-center">
                      {wishlist.length}
                    </span>
                  )}
                </Link>
              </Button>

              {/* Account */}
              <Button variant="ghost" size="icon" asChild className="hidden sm:flex">
                <Link href="/account" aria-label="Account">
                  <User className="h-5 w-5" />
                </Link>
              </Button>

              {/* Cart */}
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => setIsCartOpen(true)}
                aria-label="Shopping cart"
              >
                <ShoppingBag className="h-5 w-5" />
                {getCartCount() > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 bg-primary text-primary-foreground text-xs font-bold rounded-full flex items-center justify-center">
                    {getCartCount()}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
    </>
  )
}
