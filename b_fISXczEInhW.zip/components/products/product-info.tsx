'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  Heart,
  ShoppingBag,
  Minus,
  Plus,
  Star,
  Truck,
  RotateCcw,
  Shield,
  Share2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { useCart } from '@/lib/cart-context'
import { formatPrice, cn } from '@/lib/utils'
import type { Product } from '@/lib/data/products'
import { toast } from 'sonner'

interface ProductInfoProps {
  product: Product
}

export function ProductInfo({ product }: ProductInfoProps) {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0])
  const [quantity, setQuantity] = useState(1)
  const { addToCart, toggleWishlist, isInWishlist } = useCart()
  const inWishlist = isInWishlist(product.id)

  const handleAddToCart = () => {
    addToCart(product, selectedSize.ml, quantity)
    toast.success(`${product.name} (${selectedSize.ml}ml) added to cart`)
  }

  const handleWishlist = () => {
    toggleWishlist(product.id)
    toast.success(inWishlist ? 'Removed from wishlist' : 'Added to wishlist')
  }

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: product.name,
        text: product.description,
        url: window.location.href,
      })
    } else {
      await navigator.clipboard.writeText(window.location.href)
      toast.success('Link copied to clipboard')
    }
  }

  return (
    <div className="flex flex-col">
      {/* Brand */}
      <p className="text-primary text-sm font-medium tracking-widest uppercase">
        {product.brand}
      </p>

      {/* Title */}
      <h1 className="font-serif text-3xl lg:text-4xl text-foreground mt-2">
        {product.name}
      </h1>

      {/* Rating */}
      <div className="flex items-center gap-3 mt-4">
        <div className="flex items-center gap-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={cn(
                'h-4 w-4',
                i < Math.floor(product.rating)
                  ? 'fill-primary text-primary'
                  : 'fill-muted text-muted'
              )}
            />
          ))}
        </div>
        <span className="text-sm text-muted-foreground">
          {product.rating} ({product.reviewCount} reviews)
        </span>
      </div>

      {/* Price */}
      <div className="flex items-center gap-3 mt-6">
        <span className="text-3xl font-semibold text-foreground">
          {formatPrice(selectedSize.price)}
        </span>
        {product.originalPrice && (
          <span className="text-lg text-muted-foreground line-through">
            {formatPrice(
              (product.originalPrice / product.price) * selectedSize.price
            )}
          </span>
        )}
      </div>

      <Separator className="my-6" />

      {/* Fragrance Notes */}
      <div className="space-y-4">
        <h3 className="font-medium text-foreground">Fragrance Notes</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-secondary/50 rounded-lg">
            <p className="text-xs text-primary uppercase tracking-wider mb-1">
              Top
            </p>
            <p className="text-sm text-muted-foreground">
              {product.notes.top.join(', ')}
            </p>
          </div>
          <div className="text-center p-3 bg-secondary/50 rounded-lg">
            <p className="text-xs text-primary uppercase tracking-wider mb-1">
              Heart
            </p>
            <p className="text-sm text-muted-foreground">
              {product.notes.heart.join(', ')}
            </p>
          </div>
          <div className="text-center p-3 bg-secondary/50 rounded-lg">
            <p className="text-xs text-primary uppercase tracking-wider mb-1">
              Base
            </p>
            <p className="text-sm text-muted-foreground">
              {product.notes.base.join(', ')}
            </p>
          </div>
        </div>
      </div>

      {/* Performance */}
      <div className="flex gap-6 mt-6">
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">
            Longevity
          </p>
          <p className="text-sm text-foreground font-medium">{product.longevity}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">
            Sillage
          </p>
          <p className="text-sm text-foreground font-medium">{product.sillage}</p>
        </div>
      </div>

      <Separator className="my-6" />

      {/* Size Selection */}
      <div className="space-y-3">
        <h3 className="font-medium text-foreground">Select Size</h3>
        <div className="flex gap-3">
          {product.sizes.map((size) => (
            <button
              key={size.ml}
              onClick={() => setSelectedSize(size)}
              className={cn(
                'flex flex-col items-center justify-center px-4 py-3 border rounded-lg transition-all min-w-[80px]',
                selectedSize.ml === size.ml
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50'
              )}
            >
              <span className="text-sm font-medium text-foreground">
                {size.ml}ml
              </span>
              <span className="text-xs text-muted-foreground">
                {formatPrice(size.price)}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Quantity */}
      <div className="flex items-center gap-4 mt-6">
        <span className="text-sm text-muted-foreground">Quantity</span>
        <div className="flex items-center border border-border rounded-md">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="w-12 text-center font-medium">{quantity}</span>
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10"
            onClick={() => setQuantity(quantity + 1)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 mt-8">
        <Button
          size="lg"
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={handleAddToCart}
        >
          <ShoppingBag className="h-5 w-5 mr-2" />
          Add to Cart
        </Button>
        <Button
          size="lg"
          variant="outline"
          className={cn(inWishlist && 'border-primary text-primary')}
          onClick={handleWishlist}
        >
          <Heart
            className={cn('h-5 w-5', inWishlist && 'fill-primary text-primary')}
          />
        </Button>
        <Button size="lg" variant="outline" onClick={handleShare}>
          <Share2 className="h-5 w-5" />
        </Button>
      </div>

      {/* Buy Now */}
      <Button
        asChild
        size="lg"
        variant="secondary"
        className="mt-3"
      >
        <Link href="/checkout">Buy Now</Link>
      </Button>

      {/* Trust Badges */}
      <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-border">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Truck className="h-5 w-5 text-primary" />
          <span>Free Shipping $100+</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <RotateCcw className="h-5 w-5 text-primary" />
          <span>30-Day Returns</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Shield className="h-5 w-5 text-primary" />
          <span>Authentic</span>
        </div>
      </div>
    </div>
  )
}
