'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Heart, ShoppingBag, Star, Eye } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useCart } from '@/lib/cart-context'
import { formatPrice } from '@/lib/utils'
import type { Product } from '@/lib/data/products'
import { toast } from 'sonner'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, toggleWishlist, isInWishlist } = useCart()
  const inWishlist = isInWishlist(product.id)

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    const defaultSize = product.sizes[0]
    addToCart(product, defaultSize.ml)
    toast.success(`${product.name} added to cart`)
  }

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    toggleWishlist(product.id)
    toast.success(
      inWishlist ? 'Removed from wishlist' : 'Added to wishlist'
    )
  }

  return (
    <div className="group relative bg-card rounded-lg overflow-hidden hover-lift border border-border/50 hover:border-primary/30 transition-all duration-300">
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        {product.isNew && (
          <Badge className="bg-primary text-primary-foreground">New</Badge>
        )}
        {product.isBestSeller && (
          <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
            Best Seller
          </Badge>
        )}
        {product.isOnSale && product.originalPrice && (
          <Badge className="bg-destructive text-destructive-foreground">
            {Math.round(
              ((product.originalPrice - product.price) / product.originalPrice) * 100
            )}
            % Off
          </Badge>
        )}
      </div>

      {/* Wishlist Button */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-3 right-3 z-10 h-9 w-9 bg-background/80 backdrop-blur-sm hover:bg-background"
        onClick={handleWishlist}
        aria-label={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
      >
        <Heart
          className={`h-5 w-5 transition-colors ${
            inWishlist ? 'fill-primary text-primary' : 'text-foreground'
          }`}
        />
      </Button>

      {/* Product Image */}
      <Link href={`/product/${product.id}`} className="block">
        <div className="relative aspect-[3/4] bg-muted overflow-hidden">
          <Image
            src={product.image}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          />
          {/* Hover Overlay */}
          <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
            <Button
              size="sm"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleQuickAdd}
            >
              <ShoppingBag className="h-4 w-4 mr-2" />
              Quick Add
            </Button>
            <Button
              size="sm"
              variant="outline"
              asChild
            >
              <Link href={`/product/${product.id}`}>
                <Eye className="h-4 w-4 mr-2" />
                View
              </Link>
            </Button>
          </div>
        </div>
      </Link>

      {/* Product Info */}
      <div className="p-4">
        <Link href={`/product/${product.id}`} className="block">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            {product.brand}
          </p>
          <h3 className="font-serif text-lg text-foreground group-hover:text-primary transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>

        {/* Rating */}
        <div className="flex items-center gap-2 mt-2">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3.5 w-3.5 ${
                  i < Math.floor(product.rating)
                    ? 'fill-primary text-primary'
                    : 'fill-muted text-muted'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">
            ({product.reviewCount})
          </span>
        </div>

        {/* Notes Preview */}
        <p className="text-xs text-muted-foreground mt-2 line-clamp-1">
          {product.notes.top.slice(0, 3).join(' · ')}
        </p>

        {/* Price */}
        <div className="flex items-center gap-2 mt-3">
          <span className="font-semibold text-foreground">
            {formatPrice(product.price)}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>

        {/* Sizes */}
        <div className="flex gap-2 mt-3">
          {product.sizes.map((size) => (
            <span
              key={size.ml}
              className="text-xs px-2 py-1 bg-secondary rounded text-muted-foreground"
            >
              {size.ml}ml
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
