'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Star, ThumbsUp, Camera } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'
import type { Product } from '@/lib/data/products'
import { toast } from 'sonner'

interface ProductTabsProps {
  product: Product
}

const mockReviews = [
  {
    id: 1,
    author: 'Sarah M.',
    rating: 5,
    date: '2 weeks ago',
    title: 'Absolutely stunning fragrance!',
    content:
      'This is by far the most beautiful perfume I own. The opening is fresh and inviting, and as it dries down, it becomes this gorgeous warm and sensual scent. I get compliments everywhere I go.',
    helpful: 24,
    image: null,
  },
  {
    id: 2,
    author: 'Michael R.',
    rating: 5,
    date: '1 month ago',
    title: 'Worth every penny',
    content:
      'Bought this for my wife and she loves it. The longevity is incredible - still smells amazing after a full day. The bottle is also beautiful and looks great on her vanity.',
    helpful: 18,
    image: '/testimonials/person-1.jpg',
  },
  {
    id: 3,
    author: 'Emily W.',
    rating: 4,
    date: '2 months ago',
    title: 'Beautiful but strong',
    content:
      "The scent is gorgeous and unique. My only note is that it's quite strong, so go easy on the sprays. One or two is plenty. Otherwise, absolutely love it!",
    helpful: 12,
    image: null,
  },
]

const ratingDistribution = [
  { stars: 5, percentage: 78 },
  { stars: 4, percentage: 15 },
  { stars: 3, percentage: 5 },
  { stars: 2, percentage: 1 },
  { stars: 1, percentage: 1 },
]

export function ProductTabs({ product }: ProductTabsProps) {
  const [reviewRating, setReviewRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success('Thank you for your review! It will be published after moderation.')
  }

  return (
    <section className="bg-secondary/30 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Tabs defaultValue="description" className="space-y-8">
          <TabsList className="w-full justify-start bg-transparent border-b border-border rounded-none h-auto p-0 gap-8">
            <TabsTrigger
              value="description"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent pb-4"
            >
              Description
            </TabsTrigger>
            <TabsTrigger
              value="ingredients"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent pb-4"
            >
              Ingredients
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent pb-4"
            >
              Reviews ({product.reviewCount})
            </TabsTrigger>
          </TabsList>

          {/* Description Tab */}
          <TabsContent value="description" className="space-y-6">
            <div className="max-w-3xl">
              <p className="text-muted-foreground leading-relaxed">
                {product.description}
              </p>
              <div className="grid sm:grid-cols-2 gap-6 mt-8">
                <div className="bg-card p-6 rounded-lg border border-border">
                  <h4 className="font-medium text-foreground mb-4">
                    Scent Profile
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Family</span>
                      <span className="text-foreground capitalize">
                        {product.tags[0]}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Concentration</span>
                      <span className="text-foreground">Eau de Parfum</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Gender</span>
                      <span className="text-foreground capitalize">
                        {product.category}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="bg-card p-6 rounded-lg border border-border">
                  <h4 className="font-medium text-foreground mb-4">
                    Performance
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Longevity</span>
                      <span className="text-foreground">{product.longevity}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Sillage</span>
                      <span className="text-foreground">{product.sillage}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Best Season</span>
                      <span className="text-foreground">Fall / Winter</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Ingredients Tab */}
          <TabsContent value="ingredients" className="space-y-6">
            <div className="max-w-3xl">
              <p className="text-muted-foreground mb-6">
                Our fragrances are crafted with the finest natural and synthetic
                ingredients, carefully sourced from around the world.
              </p>
              <div className="bg-card p-6 rounded-lg border border-border">
                <h4 className="font-medium text-foreground mb-4">
                  Key Ingredients
                </h4>
                <div className="grid sm:grid-cols-3 gap-6">
                  <div>
                    <p className="text-primary text-sm font-medium mb-2">
                      Top Notes
                    </p>
                    <ul className="space-y-1">
                      {product.notes.top.map((note) => (
                        <li
                          key={note}
                          className="text-sm text-muted-foreground"
                        >
                          {note}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-primary text-sm font-medium mb-2">
                      Heart Notes
                    </p>
                    <ul className="space-y-1">
                      {product.notes.heart.map((note) => (
                        <li
                          key={note}
                          className="text-sm text-muted-foreground"
                        >
                          {note}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-primary text-sm font-medium mb-2">
                      Base Notes
                    </p>
                    <ul className="space-y-1">
                      {product.notes.base.map((note) => (
                        <li
                          key={note}
                          className="text-sm text-muted-foreground"
                        >
                          {note}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Rating Summary */}
              <div className="bg-card p-6 rounded-lg border border-border">
                <div className="text-center mb-6">
                  <p className="text-5xl font-serif text-foreground">
                    {product.rating}
                  </p>
                  <div className="flex justify-center gap-1 my-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={cn(
                          'h-5 w-5',
                          i < Math.floor(product.rating)
                            ? 'fill-primary text-primary'
                            : 'fill-muted text-muted'
                        )}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Based on {product.reviewCount} reviews
                  </p>
                </div>
                <div className="space-y-2">
                  {ratingDistribution.map((dist) => (
                    <div key={dist.stars} className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground w-8">
                        {dist.stars}
                      </span>
                      <Progress value={dist.percentage} className="h-2 flex-1" />
                      <span className="text-sm text-muted-foreground w-10">
                        {dist.percentage}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reviews List */}
              <div className="lg:col-span-2 space-y-6">
                {mockReviews.map((review) => (
                  <div
                    key={review.id}
                    className="bg-card p-6 rounded-lg border border-border"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground">
                            {review.author}
                          </p>
                          <span className="text-xs text-muted-foreground">
                            {review.date}
                          </span>
                        </div>
                        <div className="flex gap-0.5 mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={cn(
                                'h-3.5 w-3.5',
                                i < review.rating
                                  ? 'fill-primary text-primary'
                                  : 'fill-muted text-muted'
                              )}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <h4 className="font-medium text-foreground mt-4">
                      {review.title}
                    </h4>
                    <p className="text-muted-foreground text-sm mt-2">
                      {review.content}
                    </p>
                    {review.image && (
                      <div className="mt-4">
                        <div className="relative h-20 w-20 rounded-md overflow-hidden">
                          <Image
                            src={review.image}
                            alt="Review photo"
                            fill
                            className="object-cover"
                          />
                        </div>
                      </div>
                    )}
                    <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border">
                      <Button variant="ghost" size="sm" className="text-xs">
                        <ThumbsUp className="h-3.5 w-3.5 mr-1" />
                        Helpful ({review.helpful})
                      </Button>
                    </div>
                  </div>
                ))}

                {/* Write Review Form */}
                <div className="bg-card p-6 rounded-lg border border-border">
                  <h4 className="font-medium text-foreground mb-4">
                    Write a Review
                  </h4>
                  <form onSubmit={handleSubmitReview} className="space-y-4">
                    <div>
                      <Label className="text-sm text-muted-foreground">
                        Your Rating
                      </Label>
                      <div className="flex gap-1 mt-2">
                        {[...Array(5)].map((_, i) => (
                          <button
                            key={i}
                            type="button"
                            onClick={() => setReviewRating(i + 1)}
                            onMouseEnter={() => setHoveredRating(i + 1)}
                            onMouseLeave={() => setHoveredRating(0)}
                            className="p-1"
                          >
                            <Star
                              className={cn(
                                'h-6 w-6 transition-colors',
                                i < (hoveredRating || reviewRating)
                                  ? 'fill-primary text-primary'
                                  : 'fill-muted text-muted'
                              )}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="review-title">Title</Label>
                      <Input
                        id="review-title"
                        placeholder="Summarize your review"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="review-content">Your Review</Label>
                      <Textarea
                        id="review-content"
                        placeholder="Share your experience with this fragrance..."
                        rows={4}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm text-muted-foreground">
                        Add Photos (Optional)
                      </Label>
                      <div className="mt-2 border-2 border-dashed border-border rounded-lg p-6 text-center">
                        <Camera className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground">
                          Click to upload or drag and drop
                        </p>
                      </div>
                    </div>
                    <Button
                      type="submit"
                      className="bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      Submit Review
                    </Button>
                  </form>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
